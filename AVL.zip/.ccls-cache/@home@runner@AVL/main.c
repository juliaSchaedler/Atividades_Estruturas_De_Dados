#include <stdio.h>
#include <stdlib.h>

// Declaração do registro
typedef struct Node {
  int dado;
  int altura;
  struct Node *esquerda;
  struct Node *direita;
} Nodo;

// Prototipação
Nodo *criaNodo(int);
Nodo *inserir(Nodo *, int);
Nodo *deletar(Nodo *, int);
int maiorValor(int, int);
int alturaArvore(Nodo *);
int fatorBalanceamento(Nodo *);
void preOrdem(Nodo *);
void ordemSimetrica(Nodo *);
void posOrdem(Nodo *);
Nodo *valorMinimo(Nodo *);
Nodo *rotacaoDireita(Nodo *);
Nodo *rotacaoEsquerda(Nodo *);
void procura(Nodo *, int);

// Criação dos nodos
/*
Função que cria um novo nó
value -> valor a ser inserido no nó
Retorna: o endereço do nó criado;
*/
Nodo *criaNodo(int dado) {
  Nodo *nodo = (Nodo *)malloc(sizeof(struct Node));
  nodo->dado = dado;
  nodo->esquerda = NULL;
  nodo->direita = NULL;
  nodo->altura = 1;
  return nodo;
}

// Inserção de valores na AVL já fazendo o balanceamento
/*
Insere um novo nó na árvore
node -> nó da árvore
number -> valor a ser inserido
Retorna: endereço do novo nó ou nova raiz após o balanceamento
*/
Nodo *inserir(Nodo *nodo, int dado) {
  if (nodo == NULL) // Arvore vazia
    return (criaNodo(dado));

  if (dado < nodo->dado) // faz a inserção a esquerda ou direita
    nodo->esquerda = inserir(nodo->esquerda, dado);
  else if (dado > nodo->dado)
    nodo->direita = inserir(nodo->direita, dado);
  else
    return nodo;

  // Recalcula a altura de todos os nós entre a raiz e o novo nó inserido
  // A altura do nodo passa a ser o maior valor entre a esq e a dir somado 1
  nodo->altura =
      1 + maiorValor(alturaArvore(nodo->esquerda), alturaArvore(nodo->direita));

  // Verifica a necessidade de rebalancear a árvore
  int balanco = fatorBalanceamento(nodo);

  // rotação esquerda LL
  if (balanco > 1 && dado < nodo->esquerda->dado)
    return rotacaoDireita(nodo);

  // rotação a direita RR
  if (balanco < -1 && dado > nodo->direita->dado)
    return rotacaoEsquerda(nodo);

  // rotação esquerda-direita LR
  if (balanco > 1 && dado > nodo->esquerda->dado) {
    nodo->esquerda = rotacaoEsquerda(nodo->esquerda);
    return rotacaoDireita(nodo);
  }

  // Rotação direita-esquerda RL
  if (balanco < -1 && dado < nodo->direita->dado) {
    nodo->direita = rotacaoDireita(nodo->direita);
    return rotacaoEsquerda(nodo);
  }

  return nodo;
}

// Remoção de valores na AVL já fazendo o balanceamento
Nodo *deletar(Nodo *raiz, int dado) {
  if (raiz == NULL) // Se o valor não existir
    return raiz;

  if (dado < raiz->dado)
    raiz->esquerda = deletar(raiz->esquerda, dado);

  else if (dado > raiz->dado)
    raiz->direita = deletar(raiz->direita, dado);

  else {
    if ((raiz->esquerda == NULL) || (raiz->direita == NULL)) {
      Nodo *aux = raiz->esquerda ? raiz->esquerda : raiz->direita;

      if (aux == NULL) {
        aux = raiz;
        raiz = NULL;
      } else
        *raiz = *aux;
      free(aux);
    } else { // Removendo nó que possui dois flhos
      Nodo *aux = valorMinimo(raiz->direita);

      raiz->dado = raiz->dado; // Elemento trocado

      raiz->direita = deletar(raiz->direita, aux->dado);
    }
  }

  if (raiz == NULL)
    return raiz;
  // Recalcula a altura de todos os nós entre a raiz e o nó deletado
  raiz->altura =
      1 + maiorValor(alturaArvore(raiz->esquerda), alturaArvore(raiz->direita));

  // Verifica a necessidade de rebalancear a árvore
  int balanco = fatorBalanceamento(raiz);

  if (balanco > 1 && fatorBalanceamento(raiz->esquerda) >= 0)
    return rotacaoDireita(raiz); // rotação simples para direita

  if (balanco > 1 && fatorBalanceamento(raiz->esquerda) < 0) {
    raiz->esquerda = rotacaoEsquerda(raiz->esquerda);
    return rotacaoDireita(raiz); // rotação dupla esquerda->direita
  }

  if (balanco < -1 && fatorBalanceamento(raiz->direita) <= 0)
    return rotacaoEsquerda(raiz); // rotação simples para esquerda

  if (balanco < -1 && fatorBalanceamento(raiz->direita) > 0) {
    raiz->direita = rotacaoDireita(raiz->direita);
    return rotacaoEsquerda(raiz); // rotação dupla direita->esquerda
  }

  return raiz;
}

// Verifica a altura da árvore
int alturaArvore(Nodo *N) {
  if (N == NULL)
    return 0;
  return N->altura;
}

// Encontra o maior valor para fazer o balanceamento
int maiorValor(int a, int b) { return (a > b) ? a : b; }

// Encontra o fator do balanceamento
/*Fator 0: ambas esq e dir são iguais
Fator -1: dir é maior que a esq
Fator +1: esq é maior que a dir
Fatores -2 ou +2 indicam desbalanceamento*/
int fatorBalanceamento(Nodo *N) {
  int x;
  if (N == NULL) {
    return 0;
  } else {
    x = alturaArvore(N->esquerda) - alturaArvore(N->direita);
  }

  return x;
}

//------------------------------PERCURSOS EM ÁRVORE
//----------------------------//

void preOrdem(Nodo *raiz) {
  if (raiz != NULL) {
    printf("[%i] /=/ altura = %i /=/ fator = %i\n ", raiz->dado, raiz->altura,
           fatorBalanceamento(raiz));
    preOrdem(raiz->esquerda);
    preOrdem(raiz->direita);
  }
}

void ordemSimetrica(Nodo *raiz) {
  if (raiz != NULL) {
    ordemSimetrica(raiz->esquerda);
    printf("[%i] ", raiz->dado);
    ordemSimetrica(raiz->direita);
  }
}

void posOrdem(Nodo *raiz) {
  if (raiz != NULL) {
    posOrdem(raiz->esquerda);
    posOrdem(raiz->direita);
    printf("[%i] ", raiz->dado);
  }
}

//-----------------------------ROTAÇÕES PARRA BALANCEAMENTO DA ÁRVORE
//-----------------------//

Nodo *rotacaoDireita(Nodo *y) {
  Nodo *x = y->esquerda;
  Nodo *T2 = x->direita;

  x->direita = y;
  y->esquerda = T2;

  y->altura =
      maiorValor(alturaArvore(y->esquerda), alturaArvore(y->direita)) + 1;
  x->altura =
      maiorValor(alturaArvore(x->esquerda), alturaArvore(x->direita)) + 1;

  return x;
}

Nodo *rotacaoEsquerda(Nodo *x) {
  Nodo *y = x->direita;
  Nodo *T2 = y->esquerda;

  y->esquerda = x;
  x->direita = T2;

  x->altura =
      maiorValor(alturaArvore(x->esquerda), alturaArvore(x->direita)) + 1;
  y->altura =
      maiorValor(alturaArvore(y->esquerda), alturaArvore(y->direita)) + 1;

  return y;
}

// Encontra o valor mínimo na árvore
// Serve para fazer a remoção de um nó que tem 2 filhos
Nodo *valorMinimo(Nodo *nodo) {
  Nodo *x = nodo;

  while (x->esquerda != NULL) {
    x = x->esquerda;
  }
  return x;
}

// |----------------------------------------------- Implementação BUSCAR
void procura(Nodo *raiz, int dado) {
  printf("|\n| Caminho até o elemento [%d]:\n| ", dado);
  while (1) {
    printf("[%i] -> ", raiz->dado);
    if (dado == raiz->dado) {
      printf("[Encontrado]\n|\n");
      return;
    }
    if (dado > raiz->dado) {
      if (raiz->direita == NULL) {
        printf("[?]\n| [!] Elemento não encontrado. [!]\n|\n");
        return;
      }
      raiz = raiz->direita;
    } else {
      if (raiz->esquerda == NULL) {
        printf("[?]\n| [!] Elemento não encontrado. [!]\n|\n");
        return;
      }
      raiz = raiz->esquerda;
    }
  }
}

//-----------------------------MAIN--------------------------///
int main() {
  Nodo *raiz = NULL;

  raiz = inserir(raiz, 15);
  raiz = inserir(raiz, 25);
  raiz = inserir(raiz, 35);
  raiz = inserir(raiz, 45);
  raiz = inserir(raiz, 65);
  raiz = inserir(raiz, 55);
  raiz = inserir(raiz, 44);
  raiz = inserir(raiz, 34);
  raiz = inserir(raiz, 24);
  raiz = inserir(raiz, 10);
  raiz = inserir(raiz, 15);

  raiz = deletar(raiz, 25);
  raiz = deletar(raiz, 35);
  raiz = deletar(raiz, 15);

  raiz = inserir(raiz, 42);
  raiz = inserir(raiz, 40);
  raiz = inserir(raiz, 43);

  raiz = deletar(raiz, 44);

  raiz = inserir(raiz, 60);
  raiz = inserir(raiz, 70);
  raiz = inserir(raiz, 50);
  raiz = inserir(raiz, 67);
  raiz = inserir(raiz, 64);

  raiz = deletar(raiz, 65);

  printf("\n");
  printf("Pré Ordem");
  printf("\n");
  preOrdem(raiz);
  printf("\n");
  printf("-----------------------------");
  printf("\n");

  printf("\n");
  printf("Ordem Simetrica");
  printf("\n");
  ordemSimetrica(raiz);
  printf("\n");
  printf("-----------------------------");
  printf("\n");

  printf("\n");
  printf("Pós Ordem");
  printf("\n");
  posOrdem(raiz);
  printf("\n");
  printf("-----------------------------");
  printf("\n");

  // procura(raiz, 3);
  return 0;
}